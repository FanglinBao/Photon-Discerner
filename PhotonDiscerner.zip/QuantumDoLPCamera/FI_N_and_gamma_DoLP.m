% these codes are to generate Fig.(b) and (e) for the quantum DoLP camera

warning off
clear;clc

N0List = 10.^(-2:0.05:1)';
% mean photon number N

etaList = [1e-2;1];
% DoLP. We use a small value of 0.01 instead of 0 for unpolarized light to avoid numeric issues.

ratio_PD = zeros(length(N0List),length(etaList),2);
ratio_SPD = zeros(length(N0List),length(etaList),2);

for indn = 1:length(N0List)
    N0 = N0List(indn);
    nMax = max(10,10*N0); % max. number of photons considered in the simulation
    n = (0:nMax)';
    P = zeros(length(n),3); % photon statistics
    delta_N = 1e-2;
    for inde = 1:length(etaList)
        eta = etaList(inde);
        delta_eta = 1e-2;
        % ---------------- N & eta
        N = N0;
        % below are some temporary variables to help compute the photon
        % statistics
        g = N/2*eta;
        pn = 1+g/(N/2);
        mn = 1-g/(N/2);
        pn1 = 1+g/(N/2+1);
        mn1 = 1-g/(N/2+1);
        for ind=1:length(n)
            nn = n(ind);
            k = 0:nn;
            P(ind,1) = (N/2).^nn ./ (N/2+1).^(nn+2) .* sum( pn.^k .* mn.^(nn-k) ./(pn1.^(k+1)) ./(mn1.^(nn-k+1)) );
        end
        % ---------------- N & (eta+delta_eta)
        g = N/2*(eta+delta_eta);
        pn = 1+g/(N/2);
        mn = 1-g/(N/2);
        pn1 = 1+g/(N/2+1);
        mn1 = 1-g/(N/2+1);
        for ind=1:length(n)
            nn = n(ind);
            k = 0:nn;
            P(ind,2) = (N/2).^nn ./ (N/2+1).^(nn+2) .* sum( pn.^k .* mn.^(nn-k) ./(pn1.^(k+1)) ./(mn1.^(nn-k+1)) );
        end
        % ---------------- (N+delta_n) & eta
        N = N0 + delta_N;
        g = N/2*eta;
        pn = 1+g/(N/2);
        mn = 1-g/(N/2);
        pn1 = 1+g/(N/2+1);
        mn1 = 1-g/(N/2+1);
        for ind=1:length(n)
            nn = n(ind);
            k = 0:nn;
            P(ind,3) = (N/2).^nn ./ (N/2+1).^(nn+2) .* sum( pn.^k .* mn.^(nn-k) ./(pn1.^(k+1)) ./(mn1.^(nn-k+1)) );
        end
        % ---------------- computing derivatives
        pNP = (P(:,3) - P(:,1))/delta_N;
        peP = (P(:,2) - P(:,1))/delta_eta;
        Q = 1 - cumsum(P,1); % click probability
        pNQ = (Q(:,3) - Q(:,1))/delta_N;
        peQ = (Q(:,2) - Q(:,1))/delta_eta;
        % ---------------- Fisher information
        JpN = sum(pNP.^2./P(:,1));
        JpE = sum(peP.^2./P(:,1));
        JqN = max( pNQ.^2./Q(:,1)./(1-Q(:,1)) );
        JqE = max( peQ.^2./Q(:,1)./(1-Q(:,1)) ); 
        JqN_1 = pNQ(1)^2/Q(1,1)/(1-Q(1,1));
        JqE_1 = peQ(1)^2/Q(1,1)/(1-Q(1,1));
        ratio_PD(indn,inde,1) = JqN/JpN;
        ratio_PD(indn,inde,2) = JqE/JpE;
        ratio_SPD(indn,inde,1) = JqN_1/JpN;
        ratio_SPD(indn,inde,2) = JqE_1/JpE;
    end
end

figure;
loglog(N0List,ratio_PD(:,1,1),'r');hold on;loglog(N0List,ratio_PD(:,2,1),'b');
loglog(N0List,ratio_SPD(:,1,1),'r--');loglog(N0List,ratio_SPD(:,2,1),'b--');
ylim([1e-2,1]);
xlabel('Mean photon number N');ylabel('Fisher information J/J_0');
% Fig.b

temp=ratio_PD(:,1,2);
site=~isinf(temp);
xx=N0List(site);
yy=temp(site);
figure;
loglog(xx,yy,'r');hold on;loglog(N0List,ratio_PD(:,2,2),'b');
loglog(N0List,ratio_SPD(:,1,2),'r--');loglog(N0List,ratio_SPD(:,2,2),'b--');
ylim([1e-2,1]);
xlabel('Mean photon number N');ylabel('Fisher information J/J_0');
% Fig.e
