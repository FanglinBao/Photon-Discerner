clear;clc;warning off

N = 500; %10, 100, 500

NN = (N+1)/N; % temporary variables
g = 1-1/(N/2+1);

tList = 10.^(-1:0.01:1)'; % threshold/N

numT = length(tList);

ratio = zeros(numT,2);
% J/J0. The expressions below for this ratio have been analytically
% simplified.

for indt=1:numT
    t = ceil(N*tList(indt));
    % polarized
    SNR_i = 1/(N+1);
    SNR_t = t^2/(N+1)^2/N/(NN^t-1);
    ratio(indt,1) = SNR_t/SNR_i;
    % unpolarized
    SNR_i = 1/(N/2+1);
    Q=(t+1)*g^t - t*g^(t+1);
    SNR_t = N/4*(1-g)^6*t^2*(t+1)^2*( g^(2*t-2)/Q/(1-Q) );
    ratio(indt,2) = SNR_t/SNR_i;
end

figure;semilogx(tList,ratio(:,1),'b');hold on
semilogx(tList,ratio(:,2),'r');
