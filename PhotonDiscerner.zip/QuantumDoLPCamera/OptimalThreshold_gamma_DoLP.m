warning off
N0List = 10.^(-2:0.05:1)';
etaList = (1e-2:1e-2:1)';
OptThre = zeros(length(N0List),length(etaList),2);
tic;
for indn = 1:length(N0List)
    N0 = N0List(indn);
    nMax = max(10,10*N0);
    n = (0:nMax)';
    P = zeros(length(n),3);
    delta_N = 1e-2;
    for inde = 1:length(etaList)
        eta = etaList(inde);
        delta_eta = 1e-2;
        % ---------------- N & eta
        N = N0;
        g = N/2*eta;
        pn = 1+g/(N/2);
        mn = 1-g/(N/2);
        pn1 = 1+g/(N/2+1);
        mn1 = 1-g/(N/2+1);
        for ind=1:length(n)
            nn = n(ind);
            k = 0:nn;
            P(ind,1) = (N/2).^nn ./ (N/2+1).^(nn+2) .* sum( pn.^k .* mn.^(nn-k) ./(pn1.^(k+1)) ./(mn1.^(nn-k+1)) );
        end
        % ---------------- N & (eta+delta_eta)
        g = N/2*(eta+delta_eta);
        pn = 1+g/(N/2);
        mn = 1-g/(N/2);
        pn1 = 1+g/(N/2+1);
        mn1 = 1-g/(N/2+1);
        for ind=1:length(n)
            nn = n(ind);
            k = 0:nn;
            P(ind,2) = (N/2).^nn ./ (N/2+1).^(nn+2) .* sum( pn.^k .* mn.^(nn-k) ./(pn1.^(k+1)) ./(mn1.^(nn-k+1)) );
        end
        % ---------------- (N+delta_n) & eta
        N = N0 + delta_N;
        g = N/2*eta;
        pn = 1+g/(N/2);
        mn = 1-g/(N/2);
        pn1 = 1+g/(N/2+1);
        mn1 = 1-g/(N/2+1);
        for ind=1:length(n)
            nn = n(ind);
            k = 0:nn;
            P(ind,3) = (N/2).^nn ./ (N/2+1).^(nn+2) .* sum( pn.^k .* mn.^(nn-k) ./(pn1.^(k+1)) ./(mn1.^(nn-k+1)) );
        end
        % ----------------
        Q = 1 - cumsum(P,1);
        pNQ = (Q(:,3) - Q(:,1))/delta_N;
        peQ = (Q(:,2) - Q(:,1))/delta_eta;
        % ----------------
        Jn = pNQ.*pNQ./Q(:,1)./(1-Q(:,1));
        Jn(isinf(Jn))=NaN;
        [~,ind]=max(Jn);
        OptThre(indn,inde,1) = ind;
        Je = peQ.*peQ./Q(:,1)./(1-Q(:,1));
        Je(isinf(Je))=NaN;
        [~,ind]=max(Je);
        OptThre(indn,inde,2) = ind;
    end
    toc;
end

figure;
[gg,nn]=meshgrid((N0List),etaList);
[~,handle1]=contourf(gg,nn,OptThre(:,:,1)');set(handle1,'LineColor','None');hold on;
contour(gg,nn,OptThre(:,:,1)',1:10,'w--','LineWidth',0.5);
xlabel('Mean photon number N');ylabel('DoLP \gamma');

figure;
[gg,nn]=meshgrid((N0List),etaList);
[~,handle1]=contourf(gg,nn,OptThre(:,:,2)');set(handle1,'LineColor','None');hold on;
contour(gg,nn,OptThre(:,:,2)',1:10,'w--','LineWidth',0.5);
xlabel('Mean photon number N');ylabel('DoLP \gamma');
