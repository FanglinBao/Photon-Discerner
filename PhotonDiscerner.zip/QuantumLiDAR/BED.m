function [n] = BED(N,num)
%BED Summary of this function goes here

if N>0
    kMAX=max(10,6*N);
    x=0:1:kMAX;
    yPDF=PDF_BED(x,N);
    yCDF=cumsum(yPDF);
    
    n=zeros(num,1);
    for ind=1:num
        n(ind)=find(yCDF>=rand,1)-1;
    end    
else
    disp('N<=0 error');
end

end



