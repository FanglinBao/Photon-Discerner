clear;clc;warning off

N = 0.105; % actual N

% first case
QEfficiency = 0.885;
DarkCountProb = 3/(1e8); % The probability of a dark count in each counting window
% counting rate = 1e8 Hz. dark cound rate = 3 Hz.
% second case
% QEfficiency = 0.955;
% DarkCountProb = 2e4/(1e8);

ClickProb = [DarkCountProb;QEfficiency]; % p=DarkCountProb if n<t; p=QEfficiency if n>=t; 

numExperiments = 1000;
pList = round(10.^(0:0.1:4)');
numP = length(pList);
hits = zeros(numP,2);

DB_1 = 0.093; % based on estimated N=0.1
DB_2 = 0.0065;

%%
for indp=1:numP
    numPeriod = pList(indp);
    hit_spd = 0;
    rej_spd = 0;
    hit_qp = 0;
    rej_qp = 0;
    for inde=1:numExperiments
        rnd_thermal = BED(N,numPeriod);
        rnd_coherent = poissrnd(N,[numPeriod,1]);
%         darkCount_stream = binornd(1,DarkCountProb,[numPeriod,1]);
        %------------ convert photon streams to counts
        count_th_spd = binornd(1,ClickProb((rnd_thermal>=1)+1));%|darkCount_stream;
        count_th_pd  = binornd(1,ClickProb((rnd_thermal>=2)+1));%|darkCount_stream;
        count_co_spd = binornd(1,ClickProb((rnd_coherent>=1)+1));%|darkCount_stream;
        count_co_pd  = binornd(1,ClickProb((rnd_coherent>=2)+1));%|darkCount_stream;
        %------------
        if sum(count_co_spd) >= DB_1*numPeriod
            hit_spd = hit_spd+1;
        end
        if sum(count_th_spd) < DB_1*numPeriod
            rej_spd = rej_spd+1;
        end
        if sum(count_co_pd) <= DB_2*numPeriod
            hit_qp = hit_qp+1;
        end
        if sum(count_th_pd) > DB_2*numPeriod
            rej_qp = rej_qp+1;
        end
    end
    hits(indp,1)=(hit_spd+rej_spd)/2;
    hits(indp,2)=(hit_qp+rej_qp)/2;
end
figure;semilogx(pList,hits/numExperiments*100);legend({'Classical LiDAR','Quantum LiDAR'});ylim([45,100])
