clear;clc;warning off

N = 100; % 10, 100, 500
NN = (N+1)/N;
tList = 10.^(-1:0.01:1)';
numT = length(tList);
ratio = zeros(numT,2);
for indt=1:numT
    t = ceil(N*tList(indt));
    % thermal light source
    SNR_i = 1/(N+1);
    SNR_t = t^2/(N+1)^2/N/(NN^t-1);
    ratio(indt,1) = SNR_t/SNR_i;
    % coherent source
    SNR_i = 1;
    if gammainc(N,t)==1
        SNR_t = N*( poisspdf(t-1,N) )^2/gammainc(N,t,'upper')/(1-gammainc(N,t,'upper'));
    else
        SNR_t = N*( poisspdf(t-1,N) )^2/gammainc(N,t)/(1-gammainc(N,t));
    end
    ratio(indt,2) = SNR_t/SNR_i;
end

figure;semilogx(tList,ratio');
