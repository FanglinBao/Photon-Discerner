clear;clc;warning off

N = 0.12; % actual N, 0.05 ~ 0.15
numExperiments = 1000;
pList = round(10.^(0:0.1:4)');
numP = length(pList);
hits = zeros(numP,2);

DB_1 = 0.093; % based on estimated N=0.1
DB_2 = 0.0065;

%%
for indp=1:numP
    numPeriod = pList(indp);
    hit_spd = 0;
    rej_spd = 0;
    hit_qp = 0;
    rej_qp = 0;
    for inde=1:numExperiments
        rnd_thermal = BED(N,numPeriod);
        rnd_coherent = poissrnd(N,[numPeriod,1]);
        if sum(rnd_coherent>=1) >= DB_1*numPeriod
            hit_spd = hit_spd+1;
        end
        if sum(rnd_thermal>=1) < DB_1*numPeriod
            rej_spd = rej_spd+1;
        end
        if sum(rnd_coherent>=2) <= DB_2*numPeriod
            hit_qp = hit_qp+1;
        end
        if sum(rnd_thermal>=2) > DB_2*numPeriod
            rej_qp = rej_qp+1;
        end
    end
    hits(indp,1)=(hit_spd+rej_spd)/2;
    hits(indp,2)=(hit_qp+rej_qp)/2;
end
figure;semilogx(pList,hits/numExperiments*100);legend({'Classical LiDAR','Quantum LiDAR'});ylim([45,100])
