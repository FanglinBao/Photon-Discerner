clear;clc

dg = 1e-3;
gList=linspace(0.01,0.99,30)';
numG=length(gList);
nList=(0:100)';
p0 = nList.*0;
p = nList.*0;
NList = 10.^(-2:0.05:1)';
numN = length(NList);
ratio_t = zeros(numG,numN);
ratio_spd = zeros(numG,numN);
opt = zeros(numG,numN);
tList = (1:60)';
numT = length(tList);
resT = zeros(numT,1);
tic
for indg=1:numG
    g=gList(indg);
    for indN=1:numN
        N = NList(indN);
        %---------------------
        nth = N*(1-g);
        beta2 = N*g;
        beta = sqrt(beta2);
        f=@(x,nn) exp(2.*x*beta/nth-(1+1/nth).*x.^2).*x.^(2*nn)./factorial(nn).*besseli(0,2*x*beta/nth,1)*2.*x;
        for indn=1:length(nList)
            n=nList(indn);
            p0(indn)=integral(@(x)f(x,n),0,50)*exp(-beta2/nth)/nth;
%             p0(indn)=integral(@(x)f(x,n),0,Inf)*exp(-beta2/nth)/nth;
        end
        p0(isnan(p0))=0;
        %---------------------
        nth = N*(1-g-dg);
        beta2 = N*(g+dg);
        beta = sqrt(beta2);
        f=@(x,nn) exp(2.*x*beta/nth-(1+1/nth).*x.^2).*x.^(2*nn)./factorial(nn).*besseli(0,2*x*beta/nth,1)*2.*x;
        for indn=1:length(nList)
            n=nList(indn);
            p(indn)=integral(@(x)f(x,n),0,50)*exp(-beta2/nth)/nth;
%             p(indn)=integral(@(x)f(x,n),0,Inf)*exp(-beta2/nth)/nth;
        end
        p(isnan(p))=0;
        %---------------------
        pp = (p-p0)/dg;
        Site = (p0~=0);
        j0 = sum( pp(Site).^2./p0(Site) );
        for indt=1:numT
            t = tList(indt);
            %
            Q = sum(p0((t+1):end)) + eps;
            pQ = sum(pp((t+1):end));
            j = pQ^2/Q/(1-Q);
            resT(indt) = j/j0;
        end
        [v,ind] = max(resT);
        if ind==numT
            disp('threshold inaccurate');
        end
        ratio_t(indg,indN) = v;
        opt(indg,indN) = tList(ind);
        ratio_spd(indg,indN) = resT(1);
    end
    toc
end

figure;
loglog(NList,ratio_t([1,numG],:)');hold on;
loglog(NList,ratio_spd([1,numG],:)','--');hold on;
xlabel('Photon number N');ylabel('Fisher information J/J_0');
ylim([0.01,1]);

figure;
[gg,nn]=meshgrid((NList),gList);
[~,handle1]=contourf(gg,nn,(opt));set(handle1,'LineColor','None');hold on;
contour(gg,nn,opt,1:20,'w--','LineWidth',0.5);
xlabel('Photon number N');ylabel('Signal fraction g');
