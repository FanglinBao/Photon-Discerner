function [p] = PDF_BED(k,N)
%PDF_NBD Summary of this function goes here
%   PDF_NBD computes the negative binomial distribution. M=dt/tc is the
%   ratio of integration time to the coherence time. M*N is the mean photon
%   number during the integration time. N<1

p=1./(1+1./N).^k./(N+1);

end

