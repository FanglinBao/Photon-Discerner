%% This code calculates the vortex-antivortex potential barrier based on
% the current and QP calcualations.
clc;
%close all;
clear P0 P1_max IR P1_2 Umax
tic
%% Parameters

I_bv = 1;   % Bias current normalized to I_c,v % originally .85
% I_sw = 0.62585;
% I_sw = 0.6415;
I_sw = 0.7022;
I_bv_arr = I_sw*linspace(0.2,0.7,100);
% I_bv_arr = I_sw*linspace(0.55,1,100);   %.52;%100: 1.1286;.5983;.6337;.6348;%150: 0.6544;0.6513;0.6663;0.6827;%200: 0.6706;.6876;0.7004;0.7079;  % 250: 0.7009;%0.7101;%0.7158;%0.7195;
% I_bv_arr = I_sw*0.723;
n_se_2D = n_se0 - Cqp;    % 2D Density of superconducting electrons
Lambda = 2 * lambda_GL^2 / d;   % Pearl penetration depth
h0 = 6.62607004e-34;   % Planck constant
Phi0 = h0 / (2*e0); % Magnetic flux quantum
epsilon_0 = Phi0^2 / (2*pi*mu0*Lambda); % Characteristic vortex energy
epsilon = Phi0^2 * e0^2 * n_se_2D / (4*pi*me); % Characteristic vortex energy

T0=0.3; %originally 0.6K %working temperature

%% Potential calculation

for ll=1:length(I_bv_arr)
    I_bv=I_bv_arr(ll);
alpha_VH=1e34;  %it is a fitting parameter. 
kB = 1.38064852e-23;


U_v0 = epsilon_0 * (log( 2*W/(pi*xi) * cos(pi*xx/W))...
    -I_bv * 2*(xx+W/2) / (exp(1)*xi) ); % Potential barrier with no photon
Umax0=max(U_v0);
Pvh0=alpha_VH*exp(-Umax0/(kB*T0));
P0(ll)=Pvh0*T;

jj0=fix((L/2+y0)/Dy);


% figure;
% plot(xx,N_se_2D)
% figure;
% plot(xx,Jy0*W)
% TT=fix([0.03,0.1,0.5,1,5,15]*1e-12/Dt);
% TT=fix([0.03:0.04:T*1e12]*1e-12/Dt);
TT=2:length(tt);


DT=(TT(4)-TT(3))*Dt;
U_v = zeros(length(xx) , length(yy) , length(TT)); % Potential barrier
u_v = zeros(length(xx) , length(yy) , length(TT)); % Potential barrier


% figure;
for kk=1:length(TT)
    Jy0=Jy(:,jj0,TT(kk))/j0*I_bv/W;
    N_se_2D=(n_se0-Cqp(:,jj0,TT(kk)))/n_se0;
    

for ii=1:length(xx) 
    for jj=1:ii
        if xx(jj)>=-W/2+xi && xx(jj)<=W/2-xi
            u_v(jj,:,kk)= pi/W * N_se_2D(jj) * tan(pi*xx(jj)/W)...
               +2*W/exp(1)/xi * N_se_2D(jj) *Jy0(jj);
           U_v(ii,jj0,kk)= U_v(ii,jj0,kk)-epsilon_0 *u_v(jj,jj0,kk)*Dx;
           term3(ii,jj0,kk) = U_v(ii,jj0,kk);
        else
            U_v(ii,jj0,kk)=epsilon_0*(N_se_2D(jj)*log( 2*W/(pi*xi)*cos(pi*xx(jj)/W))...
                -I_bv*2*(xx(jj)+W/2)/(exp(1)*xi)*N_se_2D(jj)*Jy(jj,jj0,TT(kk))/j0);
            term1(ii,jj0,kk) = N_se_2D(jj)*log( 2*W/(pi*xi)*cos(pi*xx(jj)/W));
            term2(ii,jj0,kk) = I_bv*2*(xx(jj)+W/2)/(exp(1)*xi)*N_se_2D(jj)*Jy(jj,jj0,TT(kk))/j0;
            term3(ii,jj0,kk) = 0;
        end
    end
end


FIT=max(U_v0/epsilon_0)-max(U_v(:,jj0,1)/epsilon_0);
% FIT=0;
% figure;
% plot(xx*1e9,U_v(:,jj0,kk)/epsilon_0+FIT)
Umax(kk)= epsilon_0 * max(U_v(2:end,jj0,kk)/epsilon_0+FIT);
%hold on;

end
% figure;
% hold on
% for ii_new = 1:10
%     plot(xx*1e9,term1(:,jj0,int32(ii_new*end/10))./term2(:,jj0,int32(ii_new*end/10))+FIT)
% end
% figure;
% hold on
% for ii_new = 1:10
%     plot(xx*1e9,term1(:,jj0,int32(ii_new*end/10))+FIT)
%     plot(xx*1e9,term2(:,jj0,int32(ii_new*end/10))+FIT)
%     plot(xx*1e9,term3(:,jj0,int32(ii_new*end/10))+FIT)
% end

% figure;
% plot(xx*1e9,U_v(:,jj0,kk)/epsilon_0+FIT)
% figure;
% plot(xx*1e9,U_v0/epsilon_0)
% figure;
% plot(xx*1e9,U_v/epsilon_0)
% hold off;
% xlim([-(W/2-xi)*1e9 (W/2-xi)*1e9])
%ylim([-0.35 0.2])
%xlim([-46 -20])

Pvh= alpha_VH*exp(-Umax/(kB*T0));
[aa, bb1]=max(Pvh);
P1=0;
for kk=2:length(TT)
    P1(kk)=P1(kk-1)+Pvh(kk)*DT;
end
P1_2=1-exp(-P1);
if P1_2<0.01
    P1_2=P1;
end
for kk=2:length(TT)
    if P1_2(kk)<= 0.1*max(P1_2)
        bb2=kk;
    end
    if P1_2(kk)<= 0.9*max(P1_2)
        bb3=kk;
    end
    IR(kk)=(P1_2(kk)-P1_2(kk-1))/(TT(kk)-TT(kk-1));
end
% jitter(ll)=(TT(bb3)-TT(bb2))*Dt/1e-12;

[A B]=max(IR);
Latency=TT(B)*Dt/1e-12;
P1_max(ll)=max(P1_2);
end
% P0
% Plot figures
% 
% figure;
% plot(TT*Dt/1e-12,Umax/epsilon_0)
% figure;
% plot(TT*Dt/1e-12,Pvh/1e9)
% figure;
% plot(TT*Dt/1e-12,P1)
% figure;
% plot(TT*Dt/1e-12,P1_2)
% figure;
% plot(TT*Dt/1e-12,IR/max(IR))
% P1_max=max(P1_2)
% figure
% plot(I_bv_arr/I_sw,P0)
% figure
% plot(I_bv_arr/I_sw,jitter)
% figure
% plot(I_bv_arr/.9351,P0)
figure
plot(I_bv_arr/I_sw,P1_max)
% figure
% plot(I_bv_arr/.9351,P1_max)
toc