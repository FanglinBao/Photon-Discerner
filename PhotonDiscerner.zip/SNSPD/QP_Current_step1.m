%%This code calculates the diffusion of quasi-particles (QPs) in superconducting 
% single photon detectors (SNSPD). 

close all;
clear;
clc;
tic
%% Simulation parameters

hv = 0.3; %originally 1.5 % Photon energy. The unit is eV.
T = 1e-12 * 7.5;  % Total simulation time. The unit is s. % original value is 5e-12
x0 = 1e-9 * -0; % Photon absorption location; x component
y0 = 1e-9 * -0;  % Photon absorption location; y component: it can be zero
I_b = 10e-5;    % Bias current. The unit is amp. 
photon_num = 1;
x1 = 1e-9 * -0;

%% Geometry parameters

L = 1e-9 * 500;   % Length of the nanowire. The unit is m; % original value: 500 nm
W = 1e-9 * 100;    % Width of the nanowire. % originally 100nm
d = 1e-9 * 5;  % Thickness of the nanowire.
Dx =1e-9 * 3;   % Delta_x: grid size % paper mentions 1-3 nm % original value: 3 nm
Dy = Dx;   % Delta_y
j0 = I_b/W; % Bias current density


%% Choose either NbN, TaN, or WSi. The rest must be deactivated. 

%% NbN Parameters 

% Delta = 2.3e-3; % Cooper pairs band gap. The unit of energy is eV
% xi = 1e-9 * 4.3;   % Coherence length. The unit of length is m
% lambda_GL = 1e-9 * 430; % London penetration depth
% De = 1e-6 * 52;    % Hot-electron diffusion coef. The time unit is s
% Dqp = 1e-6 * 7.1;   % QP diffusion coef.
% etta = 0.25;    % QP generation efficiency
% thau_qp = 1e-12 * 1.6;  % QP generation time constant
% thau_r = 1e-12 * 1000; % QP recombination time constant
% me = 9.10938356e-31;     % Electron mass
% e0 = 1.60217662e-19;    % Electron charge
% mu0 = 4e-7*pi;  % vacuum permeability
% n_se0 = me /( lambda_GL^2 * mu0 * e0^2 ) * d; % Density of superconducting electrons
% N_se = n_se0 * xi * W; % Number of superconducting electrons in the nanowire

 %% TaN Parameters 
 
% Delta = 1.3e-3; % Cooper pairs band gap. The unit of energy is eV
% xi = 1e-9 * 5.3;   % Coherence length. The unit of length is m
% lambda_GL = 1e-9 * 520; % London penetration depth
% De = 1e-6 * 60;    % Hot-electron diffusion coef. The time unit is s
% Dqp = 1e-6 * 8.2;   % QP diffusion coef.
% etta = 0.5; % QP generation efficiency           %cross check with lit
% thau_qp = 1e-12 * 1.6;  % QP generation time constant
% thau_r = 1e-12 * 1000; % QP recombination time constant %cross check units
% me = 9.10938356e-31;     % Electron mass
% e0 = 1.60217662e-19;    % Electron charge
% mu0 = 4e-7*pi;  % vacuum permeability
% n_se0 = me /( lambda_GL^2 * mu0 * e0^2 ) * d; % Density of superconducting electrons
% N_se = n_se0 * xi * W; % Number of superconducting electrons in the  Xi slab

 %% WSi Parameters 

Delta = 0.53e-3; % Cooper pairs band gap. The unit of energy is eV
xi = 1e-9 * 8;   % Coherence length. The unit of length is m
lambda_GL = 1e-9 * 1400; % London penetration depth
De = 1e-6 * 75;    % Hot-electron diffusion coef. The time unit is s
Dqp = 1e-6 * 10.25;   % QP diffusion coef.
etta = 0.25;    % QP generation efficiency
thau_qp = 1e-12 * 1.6;  % QP generation time constant
thau_r = 1e-12 * 1000; % QP recombination time constant % originally 1e-2*1000
me = 9.10938356e-31;     % Electron mass
e0 = 1.60217662e-19;    % Electron charge
mu0 = 4e-7*pi;  % vacuum permeability
n_se0 = me /( lambda_GL^2 * mu0 * e0^2 ) * d; % Density of superconducting electrons % cross check to find eq.
% leif:  n_se0 = me*c^2 /(4*pi*lambda_GL^2*e0^2) -> Kittel has the above,
% which is in SI units, I think we are averaging over d to find a 2D
% density
N_se = n_se0 * xi * W; % Number of superconducting electrons in the  Xi slab % cross check to find this -> note, this is not used in code

%% Diffusion Equations

K= 0.01; %originally .01  % K = Dqp * Dt / Dx^2
Dt = K * Dx^2 / Dqp;    % Delta_t. Time steps.
xx = -W/2:Dx:W/2;    % grids in the x direction.
yy = -L/2:Dy:L/2;    % grids in the y direction.
tt = Dt:Dt:T;    % Time sweep

Cqp = zeros(length(xx) , length(yy) , length(tt));  % QP distribution 
cqp = zeros(length(xx)*length(yy) , 1); %temporary QP distribution
Phi = zeros(length(xx) , length(yy) , length(tt));  % Phi distribution
phi = zeros(length(xx)*length(yy) , 1); %Phi current distribution
Jy = zeros(length(xx) , length(yy) , length(tt));  % Current distribution
Jx = zeros(length(xx) , length(yy) , length(tt));  % Current distribution
n_se = zeros(length(xx) , length(yy)); % Superconducting electron distribution
Ce = zeros(length(xx) , length(yy) , length(tt));  % Hot electron distribution 
M1 = zeros(length(xx)*length(yy) , length(xx)*length(yy));  % FD matrix of coef. for t=kk
M2 = zeros(length(xx)*length(yy) , length(xx)*length(yy));  % FD matrix of coef. for t=kk+1
N1 = zeros(length(xx)*length(yy) , length(xx)*length(yy));  % FD matrix of coef. for current
A = zeros(length(xx)*length(yy),1); % Source matrix for QPs
B = zeros(length(xx)*length(yy),1); % Source matrix for current
Jmax = zeros(1,length(tt));  % Jmax at edge

for kk=1:length(tt)
    % QP calculation
    for ii=1:length(xx)
        for jj=1:length(yy)
            % n photon Ce
            Ce(ii,jj,kk) = photon_num*1/ (4*pi*De*tt(kk)) * exp(- ((xx(ii)-x0)^2+(yy(jj)-y0)^2) / (4*De*tt(kk))); % Gaussian function, don't fully understand normalization
            % n photon Ce x-direction
            %Ce(ii,jj,kk) = 1/ (4*pi*De*tt(kk)) * ((floor(photon_num/2)+rem(photon_num,2))*exp(- ((xx(ii)-x0)^2+(yy(jj)-y0)^2) / (4*De*tt(kk)))+(floor(photon_num/2))*exp(- ((xx(ii)+x0)^2+(yy(jj)-y0)^2) / (4*De*tt(kk)))); % Gaussian function, don't fully understand normalization    
            % 5 photon Ce x-direction
%             Ce(ii,jj,kk) = 1/ (4*pi*De*tt(kk)) * (exp(- ((xx(ii)-x0)^2+(yy(jj)-y0)^2) / (4*De*tt(kk)))+exp(- ((xx(ii)-(x0-x1))^2+(yy(jj)-y0)^2) / (4*De*tt(kk)))+exp(- ((xx(ii)-(x0-x1))^2+(yy(jj)-(y0-x1))^2) / (4*De*tt(kk)))+exp(- ((xx(ii)-(x0))^2+(yy(jj)-(y0-x1))^2) / (4*De*tt(kk)))+exp(- ((xx(ii)-(x0-2*x1))^2+(yy(jj)-y0)^2) / (4*De*tt(kk)))); % Gaussian function, don't fully understand normalization    
            
            % n photon Ce y-direction
            %Ce(ii,jj,kk) = 1/ (4*pi*De*tt(kk)) * ((floor(photon_num/2)+rem(photon_num,2))*exp(- ((xx(ii)-x0)^2+(yy(jj)-y0)^2) / (4*De*tt(kk)))+(floor(photon_num/2))*exp(- ((xx(ii)-x0)^2+(yy(jj)+y0)^2) / (4*De*tt(kk)))); % Gaussian function, don't fully understand normalization
            
            
            mm = (jj-1)*length(xx) + ii;
            % diagonal elements
            M1(mm,mm) = 1 + (-2*Dt*Dqp/Dx^2 -2*Dt*Dqp/Dy^2 -Dt/thau_r)/2 ...
                -Dt*etta*hv/(Delta*thau_qp) * exp(-tt(kk)/thau_qp) * Ce(ii,jj,kk)/n_se0/2;
            M2(mm,mm) = 1 + (+2*Dt*Dqp/Dx^2 +2*Dt*Dqp/Dy^2 +Dt/thau_r)/2 ...
                +Dt*etta*hv/(Delta*thau_qp) * exp(-tt(kk)/thau_qp) * Ce(ii,jj,kk)/n_se0/2;
            A(mm,1) = Dt*etta*hv/(Delta*thau_qp) * exp(-tt(kk)/thau_qp) * Ce(ii,jj,kk);
           
           if ii>1  %Off-diagonal elements
                M1(mm-1,mm) = +Dt*Dqp/Dx^2/2;
                M2(mm-1,mm) = -Dt*Dqp/Dx^2/2;
           end
           if ii<length(xx)
                M1(mm+1,mm) = +Dt*Dqp/Dx^2/2;
                M2(mm+1,mm) = -Dt*Dqp/Dx^2/2;
           end
           if jj>1
                M1(mm-length(xx),mm) = +Dt*Dqp/Dy^2/2;
                M2(mm-length(xx),mm) = -Dt*Dqp/Dy^2/2;
           end
           if jj<length(yy)
                M1(mm+length(xx),mm) = +Dt*Dqp/Dy^2/2;
                M2(mm+length(xx),mm) = -Dt*Dqp/Dy^2/2;
           end
           % this part seems to not do anything
           if ii==1 %Boundary conditions: constant flux for the input and output. Zero flux for the walls
               M1(mm,mm) = M1(mm,mm) + Dt*Dqp/Dx^2/2;
               M1(mm,mm) = M1(mm,mm) - Dt*Dqp/Dx^2/2;
           end
           if ii==length(xx)
               M1(mm,mm) = M1(mm,mm) + Dt*Dqp/Dx^2/2;
               M1(mm,mm) = M1(mm,mm) - Dt*Dqp/Dx^2/2;
           end
        end
    end
    
    cqp = (M2) \ (M1*cqp+A); %diffusion equation
    
    for mm=1:length(xx)*length(yy)  % Mapping to a 2D matrix
        ii=rem(mm,length(xx));
        if ii==0
            ii=length(xx);
        end
        if mm==length(xx)*length(yy)
            jj=length(yy);
        else
            jj=fix(mm/length(xx))+1;
        end
        Cqp(ii,jj,kk)=cqp(mm,1);
    end
    
    % Current calculation
    for ii=1:length(xx)
        for jj=1:length(yy)
          n_se(ii,jj) = n_se0 - Cqp(ii,jj,kk);
          mm = (jj-1)*length(xx) + ii; 
          
          if ii==1
              if jj==1
                  N1(mm,mm) = -(n_se(ii,jj)+0.5*(0+n_se(ii+1,jj)))/Dx^2 ...
              -(n_se(ii,jj)+0.5*(n_se(ii,jj)+n_se(ii,jj+1)))/Dy^2;
                  N1(mm,mm) = N1(mm,mm) + 0.5*(0+n_se(ii,jj))/Dx^2;
                  N1(mm+1,mm) = 0.5*(n_se(ii,jj)+n_se(ii+1,jj))/Dx^2;
                  N1(mm+length(xx),mm) = 0.5*(n_se(ii,jj)+n_se(ii,jj+1))/Dy^2;
              elseif jj==length(yy)
                  N1(mm,mm) = -(n_se(ii,jj)+0.5*(0+n_se(ii+1,jj)))/Dx^2 ...
              -(n_se(ii,jj)+0.5*(n_se(ii,jj-1)+n_se(ii,jj)))/Dy^2;
                  N1(mm,mm) = N1(mm,mm) + 0.5*(0+n_se(ii,jj))/Dx^2;
                  N1(mm+1,mm) = 0.5*(n_se(ii,jj)+n_se(ii+1,jj))/Dx^2;
                  N1(mm-length(xx),mm) = 0.5*(n_se(ii,jj-1)+n_se(ii,jj))/Dy^2;
                  N1(mm,mm) = N1(mm,mm) + 0.5*(n_se(ii,jj)+n_se(ii,jj))/Dy^2;
                  B(mm,1) = j0/Dy;
              else
                  N1(mm,mm) = -(n_se(ii,jj)+0.5*(0+n_se(ii+1,jj)))/Dx^2 ...
              -(n_se(ii,jj)+0.5*(n_se(ii,jj-1)+n_se(ii,jj+1)))/Dy^2;
                  N1(mm,mm) = N1(mm,mm) + 0.5*(0+n_se(ii,jj))/Dx^2;
                  N1(mm+1,mm) = 0.5*(n_se(ii,jj)+n_se(ii+1,jj))/Dx^2;
                  N1(mm-length(xx),mm) = 0.5*(n_se(ii,jj-1)+n_se(ii,jj))/Dy^2;
                  N1(mm+length(xx),mm) = 0.5*(n_se(ii,jj)+n_se(ii,jj+1))/Dy^2;
              end
              
          elseif ii==length(xx)
              if jj==1
                  N1(mm,mm) = -(n_se(ii,jj)+0.5*(n_se(ii-1,jj)+0))/Dx^2 ...
              -(n_se(ii,jj)+0.5*(n_se(ii,jj)+n_se(ii,jj+1)))/Dy^2;
                  N1(mm-1,mm) = 0.5*(n_se(ii-1,jj)+n_se(ii,jj))/Dx^2;
                  N1(mm,mm) = N1(mm,mm) + 0.5*(n_se(ii,jj)+0)/Dx^2;
                  N1(mm+length(xx),mm) = 0.5*(n_se(ii,jj)+n_se(ii,jj+1))/Dy^2;
              elseif jj==length(yy)
                  N1(mm,mm) = -(n_se(ii,jj)+0.5*(n_se(ii-1,jj)+0))/Dx^2 ...
              -(n_se(ii,jj)+0.5*(n_se(ii,jj-1)+n_se(ii,jj)))/Dy^2;
                  N1(mm-1,mm) = 0.5*(n_se(ii-1,jj)+n_se(ii,jj))/Dx^2;
                  N1(mm,mm) = N1(mm,mm) + 0.5*(n_se(ii,jj)+0)/Dx^2;
                  N1(mm-length(xx),mm) = 0.5*(n_se(ii,jj-1)+n_se(ii,jj))/Dy^2;
                  N1(mm,mm) = N1(mm,mm) + 0.5*(n_se(ii,jj)+n_se(ii,jj))/Dy^2;
                  B(mm,1) = j0/Dy;
              else
                  N1(mm,mm) = -(n_se(ii,jj)+0.5*(n_se(ii-1,jj)+0))/Dx^2 ...
              -(n_se(ii,jj)+0.5*(n_se(ii,jj-1)+n_se(ii,jj+1)))/Dy^2;
                  N1(mm-1,mm) = 0.5*(n_se(ii-1,jj)+n_se(ii,jj))/Dx^2;
                  N1(mm,mm) = N1(mm,mm) + 0.5*(n_se(ii,jj)+0)/Dx^2;
                  N1(mm-length(xx),mm) = 0.5*(n_se(ii,jj-1)+n_se(ii,jj))/Dy^2;
                  N1(mm+length(xx),mm) = 0.5*(n_se(ii,jj)+n_se(ii,jj+1))/Dy^2;
              end
              
          elseif jj==1
              N1(mm,mm) = -(n_se(ii,jj)+0.5*(n_se(ii-1,jj)+n_se(ii+1,jj)))/Dx^2 ...
              -(n_se(ii,jj)+0.5*(n_se(ii,jj)+n_se(ii,jj+1)))/Dy^2;
              N1(mm-1,mm) = 0.5*(n_se(ii-1,jj)+n_se(ii,jj))/Dx^2;
              N1(mm+1,mm) = 0.5*(n_se(ii,jj)+n_se(ii+1,jj))/Dx^2;
              N1(mm+length(xx),mm) = 0.5*(n_se(ii,jj)+n_se(ii,jj+1))/Dy^2;
          
          elseif jj==length(yy)
              N1(mm,mm) = -(n_se(ii,jj)+0.5*(n_se(ii-1,jj)+n_se(ii+1,jj)))/Dx^2 ...
              -(n_se(ii,jj)+0.5*(n_se(ii,jj-1)+n_se(ii,jj)))/Dy^2;
              N1(mm-1,mm) = 0.5*(n_se(ii-1,jj)+n_se(ii,jj))/Dx^2;
              N1(mm+1,mm) = 0.5*(n_se(ii,jj)+n_se(ii+1,jj))/Dx^2;
              N1(mm-length(xx),mm) = 0.5*(n_se(ii,jj-1)+n_se(ii,jj))/Dy^2;
              N1(mm,mm) = N1(mm,mm) + 0.5*(n_se(ii,jj)+n_se(ii,jj))/Dy^2;
              B(mm,1) = j0/Dy;
          
          else   
          N1(mm,mm) = -(n_se(ii,jj)+0.5*(n_se(ii-1,jj)+n_se(ii+1,jj)))/Dx^2 ...
              -(n_se(ii,jj)+0.5*(n_se(ii,jj-1)+n_se(ii,jj+1)))/Dy^2;
          N1(mm-1,mm) = 0.5*(n_se(ii-1,jj)+n_se(ii,jj))/Dx^2;
          N1(mm+1,mm) = 0.5*(n_se(ii,jj)+n_se(ii+1,jj))/Dx^2;
          N1(mm-length(xx),mm) = 0.5*(n_se(ii,jj-1)+n_se(ii,jj))/Dy^2;
          N1(mm+length(xx),mm) = 0.5*(n_se(ii,jj)+n_se(ii,jj+1))/Dy^2;
          end
      
        end
    end
    
    B=-B;
    phi= N1 \ B;
    
    for mm=1:length(xx)*length(yy)  % Mapping to a 2D matrix
        ii=rem(mm,length(xx));
        if ii==0
            ii=length(xx);
        end
        if mm==length(xx)*length(yy)
            jj=length(yy);
        else
            jj=fix(mm/length(xx))+1;
        end
        Phi(ii,jj,kk)=phi(mm,1);
    end
    for ii=1:length(xx)
        for jj=1:length(yy)
            if jj==1
                Jy(ii,jj,kk)=j0;
                    elseif jj==length(yy)
                        Jy(ii,jj,kk)=j0;
                    else
                        Jy(ii,jj,kk)= n_se(ii,jj) * (Phi(ii,jj+1,kk)-Phi(ii,jj,kk))/Dy;
            end
            if ii==length(xx) || ii==length(xx)-1
                Jx(ii,jj,:)=0;
            else
                Jx(ii,jj,kk)=n_se(ii,jj) * (Phi(ii+1,jj,kk)-Phi(ii,jj,kk))/Dx;
            end
        end
    end
    
    Jmax(kk)=max(Jy(length(xx)-fix(xi/Dx),:,kk))/j0;
end


%% Results

figure (23);
[X,Y]=meshgrid(xx,yy);
surface(X'*1e9,Y'*1e9,Ce(:,:,kk),'EdgeColor', 'none');
colorbar;
colormap(jet);
xlim([-W/2*1e9 W/2*1e9])
ylim([-L/2*1e9 L/2*1e9])

figure (24);
surface(X'*1e9,Y'*1e9,Cqp(:,:,kk)/n_se0,'EdgeColor', 'none');
colorbar;
colormap(jet);
xlim([-W/2*1e9 W/2*1e9])
ylim([-L/2*1e9 L/2*1e9])
caxis([0 0.35])

figure (13);
surface(X'*1e9,Y'*1e9,Phi(:,:,kk),'EdgeColor', 'none');
colorbar;
colormap(jet);
xlim([-W/2*1e9 W/2*1e9])
ylim([-L/2*1e9 L/2*1e9])
% caxis([0 0.41])

figure (14);
surface(X'*1e9,Y'*1e9,Jy(:,:,kk)/j0,'EdgeColor', 'none');
colorbar;
colormap(jet);
xlim([-W/2*1e9 W/2*1e9])
ylim([-L/2*1e9 L/2*1e9])
caxis([0.3 1.25])

figure (15);
plot(tt*1e12,Jmax);
xlabel('time (ps)')
ylabel('Jmax')

figure %(16);
surface(X'*1e9,Y'*1e9,Jy(:,:,kk)/j0.*(n_se0-Cqp(:,:,kk))/n_se0,'EdgeColor', 'none');
colorbar;
colormap(jet);
xlim([-W/2*1e9 W/2*1e9])
ylim([-L/2*1e9 L/2*1e9])
toc
